#%%
import xmlschema

XSD_PATH = "operator.xsd"
XML_PATH = "operator.xml"

def main():
    # Charger le schéma
    schema = xmlschema.XMLSchema(XSD_PATH)

    # Valider le document
    try:
        schema.validate(XML_PATH)
        print("XML is valid against operator.xsd")
    except xmlschema.XMLSchemaValidationError as e:
        print("XML is NOT valid:")
        print(e)
        # Si tu veux plus de détails :
        for error in schema.iter_errors(XML_PATH):
            print(f"- {error}")

if __name__ == "__main__":
    main()

# %%
from lxml import etree

# Noms des fichiers
xml_filename = "operator.xml"
xsd_filename = "operator.xsd"

try:
    # 1. Charger le Schéma XSD
    xsd_doc = etree.parse(xsd_filename)
    xsd = etree.XMLSchema(xsd_doc)
    
    # 2. Charger le XML
    xml_doc = etree.parse(xml_filename)
    
    # 3. Tenter la validation
    is_valid = xsd.validate(xml_doc)
    
    if is_valid:
        print("✅ LE FICHIER EST VALIDE !")
    else:
        print("❌ ERREUR DE VALIDATION :")
        # Affiche l'erreur exacte (c'est ça qu'on veut voir !)
        print(xsd.error_log)

except Exception as e:
    print(f"Erreur lors du chargement : {e}")
# %%
